from setuptools import setup
 
setup(name = "client_messenger",
      version = "2.0",
      author = "Alex_Pryakhin",
      author_email = "alex@alex.ru",
      packages=["main"],
      description="A Simple Math Package",
      url="http://www.alex.org"
      )