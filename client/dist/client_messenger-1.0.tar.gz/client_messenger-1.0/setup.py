from setuptools import setup
 
setup(name = "client_messenger",
      version = "1.0",
      author = "Alex_Pryakhin",
      author_email = "alex@alex.ru",
      packages=["main"]
      )